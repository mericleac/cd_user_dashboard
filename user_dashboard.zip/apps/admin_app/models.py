from django.db import models
from apps.login_reg_app.models import *
from apps.user_app.models import *
